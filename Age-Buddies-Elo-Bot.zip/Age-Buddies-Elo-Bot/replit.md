# Discord AoE2 ELO Bot

## Overview
A Discord bot that automatically manages role assignments based on Age of Empires 2 player ELO ratings. The bot fetches player stats from aoe2insights.com and assigns appropriate Discord roles based on configured ELO tiers.

## Current State
- Bot code implemented and ready to run
- Dependencies installed (discord.py, aiohttp)
- Workflow configured to run the bot
- DISCORD_TOKEN stored in Replit Secrets
- Requires privileged intents to be enabled in Discord Developer Portal

## Project Architecture

### Main Files
- `bot.py` - Main bot application with commands and daily update task
- `requirements.txt` - Python dependencies
- `README.md` - Setup and usage documentation
- `.gitignore` - Python-specific ignore patterns

### Key Features
1. **!elo Command** - Manual ELO check and role assignment for the user who runs it
2. **!auto Command** - Admin-only command to check and update ELO roles for all server members
3. **Smart Name Matching** - Tries both Discord nickname and username when searching for AoE2 profiles
4. **Exact Name Verification** - Ensures returned player name exactly matches search term (prevents wrong role assignments from partial API matches)
5. **AoE2 Companion API** - Uses data.aoe2companion.com API for accurate ELO data
6. **Daily Automated Updates** - Runs every 24 hours to sync all members' roles
7. **7 ELO Tiers** - Configurable role tiers from 0-699 up to 2000+
8. **Random Map 1v1 Rankings** - Fetches leaderboard data for the standard ranked 1v1 mode
9. **Graceful Error Handling** - Only assigns roles when player profile is found; provides helpful error messages

### Configuration
- `GUILD_ID` - Discord server ID (currently: 1316373478450135051)
- `ROLE_TIERS` - List of (min_elo, max_elo, role_id) tuples
- `DISCORD_TOKEN` - Bot token stored in environment secrets

## Dependencies
- discord.py 2.6.4+ - Discord API wrapper
- aiohttp 3.13.2+ - Async HTTP requests for AoE2 API
- Python 3.11

## Required Discord Setup
The bot requires two privileged intents to be enabled in Discord Developer Portal:
1. **Server Members Intent** - Required for iterating guild members during daily updates
2. **Message Content Intent** - Required for reading !elo commands

## Recent Changes
- 2025-11-15: Initial project setup
- Created bot.py with ELO fetching and role management
- Configured Replit workflow for continuous bot operation
- Added comprehensive documentation
- Added smart name matching - bot now tries both Discord nickname and username when looking up AoE2 profiles
- Switched from World's Edge API to AoE2 Companion API (data.aoe2companion.com) for accurate data
- Removed web scraping dependencies (BeautifulSoup4/lxml) in favor of official JSON API
- Added !roles command to help users find role IDs for configuration
- Improved error handling - bot no longer crashes when role IDs are incorrect
- Added helpful user-facing error messages when role assignment fails
- **CRITICAL FIX**: Added exact name matching verification - prevents assigning roles based on partial API matches (e.g., "Andreyyy" matching "Andreygg")
- Bot successfully running and connected to Discord

## User Preferences
None specified yet.

## Next Steps
User needs to:
1. Enable privileged intents in Discord Developer Portal
2. Configure role IDs to match their Discord server
3. Verify guild ID is correct
4. Ensure bot has proper permissions in the server

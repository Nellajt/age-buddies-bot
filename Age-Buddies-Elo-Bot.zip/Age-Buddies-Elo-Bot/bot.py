import discord
from discord.ext import commands, tasks
import aiohttp
import os

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

GUILD_ID = 1316373478450135051

ROLE_TIERS = [
    (0, 699, 1427392532471615498),
    (700, 899, 1427392538758742166),
    (900, 999, 1427387606257373214),
    (1000, 1099, 1432734313257893933),
    (1100, 1299, 1427386779845001226),
    (1300, 1999, 1427392540797046906),
    (2000, 9999, 1432484034079887430)
]

async def fetch_elo(username: str):
    api_url = f"https://data.aoe2companion.com/api/nightbot/rank?leaderboard_id=3&search={username}&flag=false"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(api_url) as resp:
            if resp.status != 200:
                return None
            
            try:
                text = await resp.text()
                text = text.strip().strip('"')
                
                if "not found" in text.lower() or "no games" in text.lower():
                    return None
                
                import re
                
                name_match = re.match(r'^\s*(.+?)\s*\(', text)
                if not name_match:
                    return None
                
                returned_name = name_match.group(1).strip().replace(" ", "").lower()
                normalized_search = username.strip().replace(" ", "").lower()
                if returned_name != normalized_search:
                    return None
                
                elo_match = re.search(r'\((\d+)\)', text)
                if not elo_match:
                    return None
                
                current_elo = int(elo_match.group(1))
                return current_elo
                
            except Exception as e:
                print(f"Error parsing ELO response: {e}")
                return None

async def fetch_elo_with_fallback(member: discord.Member):
    nickname = member.display_name.replace(" ", "")
    username = member.name.replace(" ", "")
    
    result = await fetch_elo(nickname)
    if result is not None:
        return result, nickname
    
    if nickname != username:
        result = await fetch_elo(username)
        if result is not None:
            return result, username
    
    return None, None

def get_role_for_elo(elo: int):
    for low, high, role_id in ROLE_TIERS:
        if low <= elo <= high:
            return role_id
    return None

async def assign_elo_role(member: discord.Member, elo: int):
    guild = member.guild
    target_role_id = get_role_for_elo(elo)
    if target_role_id is None:
        print(f"⚠️ No role tier found for ELO {elo}")
        return "no_tier"
    
    target_role = guild.get_role(target_role_id)
    if target_role is None:
        print(f"❌ Role ID {target_role_id} not found in server! Please update ROLE_TIERS in bot.py")
        return "role_not_found"
    
    roles_to_remove = [
        guild.get_role(rid)
        for _, _, rid in ROLE_TIERS
        if guild.get_role(rid) is not None and guild.get_role(rid) in member.roles
    ]
    
    try:
        for role in roles_to_remove:
            if role:
                await member.remove_roles(role)
        
        await member.add_roles(target_role)
        return "success"
    except discord.Forbidden:
        print(f"❌ Missing permissions! Bot needs 'Manage Roles' permission in server settings")
        return "no_permission"
    except Exception as e:
        print(f"❌ Error assigning role: {e}")
        return "error"

@bot.command()
async def elo(ctx):
    current_elo, found_name = await fetch_elo_with_fallback(ctx.author)
    if current_elo is None:
        await ctx.send(f"❌ Could not find AoE2 profile for **{ctx.author.display_name}** or **{ctx.author.name}**.")
        return
    status = await assign_elo_role(ctx.author, current_elo)
    
    if status == "success":
        await ctx.send(
            f"📊 **{ctx.author.display_name}** (found as **{found_name}**)\n"
            f"Current Elo: **{current_elo}**\n"
            f"✅ Role updated!"
        )
    elif status == "no_permission":
        await ctx.send(
            f"📊 **{ctx.author.display_name}** (found as **{found_name}**)\n"
            f"Current Elo: **{current_elo}**\n\n"
            f"❌ **Bot lacks permissions!**\n"
            f"An admin needs to give the bot **'Manage Roles'** permission in Server Settings → Roles.\n"
            f"Also make sure the bot's role is **higher** in the role list than the ELO tier roles."
        )
    elif status == "role_not_found":
        await ctx.send(
            f"📊 **{ctx.author.display_name}** (found as **{found_name}**)\n"
            f"Current Elo: **{current_elo}**\n\n"
            f"⚠️ **Role configuration error!**\n"
            f"Ask an admin to check the role IDs in bot.py (lines 13-20)"
        )
    else:
        await ctx.send(
            f"📊 **{ctx.author.display_name}** (found as **{found_name}**)\n"
            f"Current Elo: **{current_elo}**\n\n"
            f"⚠️ Role assignment failed - check the console for details."
        )

@bot.command()
@commands.guild_only()
async def auto(ctx):
    if not ctx.author.guild_permissions.administrator:
        await ctx.send("❌ Only administrators can use this command.")
        return
    
    await ctx.send("🔄 Starting ELO check for all members... This may take a while.")
    
    guild = ctx.guild
    updated = 0
    skipped = 0
    errors = 0
    
    for member in guild.members:
        if member.bot:
            continue
        
        current_elo, found_name = await fetch_elo_with_fallback(member)
        if current_elo is None:
            skipped += 1
            continue
        
        status = await assign_elo_role(member, current_elo)
        if status == "success":
            updated += 1
        else:
            errors += 1
    
    await ctx.send(
        f"✅ **ELO check complete!**\n"
        f"Updated: **{updated}** members\n"
        f"Skipped: **{skipped}** (no profile found)\n"
        f"Errors: **{errors}**"
    )

@tasks.loop(hours=24)
async def daily_update():
    guild = bot.get_guild(GUILD_ID)
    if guild is None:
        return
    print("Running daily Elo check...")
    for member in guild.members:
        if member.bot:
            continue
        current_elo, found_name = await fetch_elo_with_fallback(member)
        if current_elo is None:
            continue
        status = await assign_elo_role(member, current_elo)
        if status == "success":
            print(f"✅ Updated {member.display_name} (found as {found_name}): {current_elo} ELO")
        else:
            print(f"⚠️ Found {member.display_name} (as {found_name}): {current_elo} ELO, but role assignment failed ({status})")
    print("Daily Elo update done.")

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    daily_update.start()

bot.run(os.environ["DISCORD_TOKEN"])

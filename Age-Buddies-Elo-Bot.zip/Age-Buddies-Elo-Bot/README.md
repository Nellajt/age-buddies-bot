# Discord AoE2 ELO Bot

A Discord bot that automatically assigns roles to server members based on their Age of Empires 2 ELO ratings.

## Features

- **!elo command**: Users can check their ELO ratings from AoE2 Companion API
- **Reliable API**: Uses the AoE2 Companion API for accurate player data retrieval
- **Automatic role assignment**: Assigns roles based on ELO tiers
- **Daily updates**: Automatically checks and updates all members' roles every 24 hours
- **7 ELO tiers**:
  - 0-699
  - 700-899
  - 900-999
  - 1000-1099
  - 1100-1299
  - 1300-1999
  - 2000+

## Setup Instructions

### 1. Enable Privileged Intents in Discord Developer Portal

The bot requires special permissions to function properly:

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Select your bot application
3. Click on the "Bot" tab in the left sidebar
4. Scroll down to "Privileged Gateway Intents"
5. Enable the following intents:
   - **SERVER MEMBERS INTENT** (required for daily role updates)
   - **MESSAGE CONTENT INTENT** (required for commands)
6. Click "Save Changes"

### 2. Invite the Bot to Your Server

Make sure your bot has these permissions:
- Manage Roles
- Read Messages/View Channels
- Send Messages
- Read Message History

### 3. Configure Role IDs

Edit the `ROLE_TIERS` list in `bot.py` to match your server's role IDs:

```python
ROLE_TIERS = [
    (0, 699, YOUR_ROLE_ID_HERE),
    (700, 899, YOUR_ROLE_ID_HERE),
    # ... etc
]
```

To get a role ID:
1. Enable Developer Mode in Discord (User Settings > Advanced > Developer Mode)
2. Right-click on a role and select "Copy ID"

### 4. Set Your Guild ID

Update the `GUILD_ID` in `bot.py` with your Discord server's ID:

```python
GUILD_ID = YOUR_GUILD_ID_HERE
```

To get your guild ID:
1. Right-click on your server name
2. Select "Copy Server ID"

## Running the Bot

The bot is configured to run automatically on Replit. Just click the "Run" button and the bot will start.

The bot will:
- Connect to Discord
- Start listening for !elo commands
- Begin daily automated ELO checks at 24-hour intervals

## Usage

**Available Commands:**

- **`!elo`** - Check your AoE2 ELO and get assigned the appropriate role
- **`!roles`** - List all server role IDs (helpful for configuration)

**How !elo works:**
The bot will:
1. Fetch your AoE2 profile from the AoE2 Companion API (tries both nickname and username)
2. Display your current ELO rating
3. Show which name was found
4. Automatically assign the appropriate role

**Smart Name Matching:**
The bot automatically tries to find your AoE2 profile by:
1. First checking your Discord server nickname
2. If not found, checking your Discord username
3. This means it works whether you've set a nickname or not!

## Troubleshooting

**Bot won't start:**
- Make sure you've enabled the privileged intents in the Discord Developer Portal
- Verify your DISCORD_TOKEN is set correctly in Replit Secrets

**Roles not being assigned:**
- Use the **`!roles`** command to see all role IDs in your server
- Check that the bot has "Manage Roles" permission in server settings
- Ensure the bot's role is higher in the hierarchy than the roles it's trying to assign
- Verify the role IDs in ROLE_TIERS (lines 13-20 in bot.py) match your server's actual roles
- If you see "Role ID not found" errors in the console, the role IDs are incorrect

**Can't find user profile:**
- The bot searches for profiles using both your Discord nickname AND username
- Make sure at least one of these matches your AoE2 in-game name on the official leaderboard
- Spaces in names are automatically removed during the search
- Your profile must be ranked in Random Map 1v1 to appear in the leaderboard

# Deploy Discord ELO Bot to Railway

This guide will help you deploy your Discord bot to Railway.app for free 24/7 hosting.

## Prerequisites
- A Railway account (sign up at https://railway.app)
- Your Discord bot token (the `DISCORD_TOKEN` you used in Replit)

## Deployment Steps

### Option 1: Deploy from GitHub (Recommended)

1. **Push your code to GitHub**
   - Download this project as a ZIP from Replit
   - Create a new GitHub repository
   - Upload all the files (bot.py, requirements.txt, etc.)

2. **Create a Railway project**
   - Go to https://railway.app/new
   - Click "Deploy from GitHub repo"
   - Select your repository
   - Railway will automatically detect it's a Python project

3. **Add environment variables**
   - In your Railway project, go to the "Variables" tab
   - Click "New Variable"
   - Add: `DISCORD_TOKEN` = (paste your Discord bot token)

4. **Deploy**
   - Railway will automatically build and deploy your bot
   - Your bot will start running in about 1-2 minutes
   - Check the "Deployments" tab to see logs

### Option 2: Deploy using Railway CLI

1. **Install Railway CLI**
   ```bash
   npm install -g @railway/cli
   ```

2. **Login to Railway**
   ```bash
   railway login
   ```

3. **Initialize and deploy**
   ```bash
   railway init
   railway up
   ```

4. **Set environment variable**
   ```bash
   railway variables set DISCORD_TOKEN=your_token_here
   ```

## Important Configuration

### Update Guild ID and Role IDs
Before deploying, make sure to update `bot.py` with your server's information:

**Line 11**: Set your Discord server ID
```python
GUILD_ID = 1316373478450135051  # Replace with YOUR server ID
```

**Lines 13-20**: Set your role IDs
```python
ROLE_TIERS = [
    (0, 699, YOUR_ROLE_ID),      # Replace with your actual role IDs
    (700, 899, YOUR_ROLE_ID),
    # ... etc
]
```

## Verify Deployment

Once deployed, check that your bot is working:

1. Go to your Discord server
2. Check if the bot shows as "Online"
3. Try the `!elo` command
4. Check Railway logs for any errors

## Railway Free Tier

- **$5 free credits per month** (plenty for a Discord bot)
- Your bot runs 24/7 as long as you have credits
- No need to keep your computer on

## Monitoring

- View logs in Railway dashboard under "Deployments"
- Check resource usage under "Metrics"
- Receive alerts if your bot goes down

## Troubleshooting

**Bot not starting?**
- Check that DISCORD_TOKEN is set correctly in Variables
- View deployment logs for error messages

**Bot offline in Discord?**
- Make sure privileged intents are enabled in Discord Developer Portal:
  - Server Members Intent
  - Message Content Intent

**Out of credits?**
- Add a payment method to Railway for additional credits
- Or redeploy on the first of the month when credits reset

## Cost

Railway's free tier gives you **$5/month** in credits, which is more than enough for a small Discord bot like this. Your bot uses minimal resources and should stay well within the free tier.

## Support

If you run into issues:
- Check Railway documentation: https://docs.railway.app
- View bot logs in Railway dashboard
- Check Discord Developer Portal for bot status
